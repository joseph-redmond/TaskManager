var dir_790326c42a690eb64f1f86583ea5c0ca =
[
    [ "TaskAdapter.java", "TaskAdapter_8java.html", "TaskAdapter_8java" ]
];