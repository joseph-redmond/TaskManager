var dir_de6ed8839a0fe66b2d9e3a1b3db17b83 =
[
    [ "ReminderType.java", "ReminderType_8java.html", "ReminderType_8java" ],
    [ "Urgency.java", "Urgency_8java.html", "Urgency_8java" ]
];