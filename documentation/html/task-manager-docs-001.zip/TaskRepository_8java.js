var TaskRepository_8java =
[
    [ "tech.joestoolbox.taskmanager.repository.TaskRepository", "interfacetech_1_1joestoolbox_1_1taskmanager_1_1repository_1_1TaskRepository.html", "interfacetech_1_1joestoolbox_1_1taskmanager_1_1repository_1_1TaskRepository" ]
];