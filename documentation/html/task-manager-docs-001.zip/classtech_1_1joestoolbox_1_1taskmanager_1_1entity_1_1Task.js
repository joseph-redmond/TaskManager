var classtech_1_1joestoolbox_1_1taskmanager_1_1entity_1_1Task =
[
    [ "body", "classtech_1_1joestoolbox_1_1taskmanager_1_1entity_1_1Task.html#aebfa8190badbe0ffb4824cc2fbb59a79", null ],
    [ "deadline", "classtech_1_1joestoolbox_1_1taskmanager_1_1entity_1_1Task.html#a3f54d6791d0951ef7816d94451e0061f", null ],
    [ "id", "classtech_1_1joestoolbox_1_1taskmanager_1_1entity_1_1Task.html#a2a7cf071f46752422ac7733d7f405d08", null ],
    [ "project", "classtech_1_1joestoolbox_1_1taskmanager_1_1entity_1_1Task.html#abde62eb421387c391c762ce44d5520ca", null ],
    [ "title", "classtech_1_1joestoolbox_1_1taskmanager_1_1entity_1_1Task.html#afb9c7ccccc23fda3bf2a52f98b9e9b75", null ],
    [ "urgency", "classtech_1_1joestoolbox_1_1taskmanager_1_1entity_1_1Task.html#ae395d78842b9c1b804eba9d9abf56e73", null ]
];