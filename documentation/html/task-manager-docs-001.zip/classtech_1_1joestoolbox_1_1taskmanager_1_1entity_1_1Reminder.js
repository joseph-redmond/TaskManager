var classtech_1_1joestoolbox_1_1taskmanager_1_1entity_1_1Reminder =
[
    [ "body", "classtech_1_1joestoolbox_1_1taskmanager_1_1entity_1_1Reminder.html#a716f4cda890d4fd2ff03992f01073933", null ],
    [ "complete", "classtech_1_1joestoolbox_1_1taskmanager_1_1entity_1_1Reminder.html#ad2f41881ca34686b519b697a9a8bdd87", null ],
    [ "deadline", "classtech_1_1joestoolbox_1_1taskmanager_1_1entity_1_1Reminder.html#a455053b2d98aff72ef3defda0976296f", null ],
    [ "id", "classtech_1_1joestoolbox_1_1taskmanager_1_1entity_1_1Reminder.html#a93b7fd79c39b03bf166359e2fcbb8f65", null ],
    [ "type", "classtech_1_1joestoolbox_1_1taskmanager_1_1entity_1_1Reminder.html#a8291988a998ab876eccec3edb6f40f26", null ]
];