var Task_8java =
[
    [ "tech.joestoolbox.taskmanager.entity.Task", "classtech_1_1joestoolbox_1_1taskmanager_1_1entity_1_1Task.html", "classtech_1_1joestoolbox_1_1taskmanager_1_1entity_1_1Task" ]
];