var classtech_1_1joestoolbox_1_1taskmanager_1_1entity_1_1Meeting =
[
    [ "deadline", "classtech_1_1joestoolbox_1_1taskmanager_1_1entity_1_1Meeting.html#aaf2af66db6247ff2610687c331fc1f37", null ],
    [ "description", "classtech_1_1joestoolbox_1_1taskmanager_1_1entity_1_1Meeting.html#ab7149f62fb2ffd6158a0485f8ec36aea", null ],
    [ "id", "classtech_1_1joestoolbox_1_1taskmanager_1_1entity_1_1Meeting.html#a43ca8f0e6d5d4508bcbbcaea99b15913", null ],
    [ "title", "classtech_1_1joestoolbox_1_1taskmanager_1_1entity_1_1Meeting.html#ac09fa97ce2081dbdf0af9e4951ab3c67", null ],
    [ "urgency", "classtech_1_1joestoolbox_1_1taskmanager_1_1entity_1_1Meeting.html#a4a4c70b552dfdb9ea9c0630d70c4f937", null ]
];