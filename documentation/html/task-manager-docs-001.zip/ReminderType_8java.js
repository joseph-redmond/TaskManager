var ReminderType_8java =
[
    [ "tech.joestoolbox.taskmanager.enums.ReminderType", "enumtech_1_1joestoolbox_1_1taskmanager_1_1enums_1_1ReminderType.html", "enumtech_1_1joestoolbox_1_1taskmanager_1_1enums_1_1ReminderType" ]
];