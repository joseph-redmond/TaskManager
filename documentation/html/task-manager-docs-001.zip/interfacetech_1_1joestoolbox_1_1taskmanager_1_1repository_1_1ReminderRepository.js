var interfacetech_1_1joestoolbox_1_1taskmanager_1_1repository_1_1ReminderRepository =
[
    [ "findAllRemindersOrderByDeadline", "interfacetech_1_1joestoolbox_1_1taskmanager_1_1repository_1_1ReminderRepository.html#a520613e46fb2289d7862c2759e1a6903", null ]
];