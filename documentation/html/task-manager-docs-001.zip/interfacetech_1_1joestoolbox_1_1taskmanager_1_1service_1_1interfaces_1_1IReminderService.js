var interfacetech_1_1joestoolbox_1_1taskmanager_1_1service_1_1interfaces_1_1IReminderService =
[
    [ "createReminder", "interfacetech_1_1joestoolbox_1_1taskmanager_1_1service_1_1interfaces_1_1IReminderService.html#ab503029edeaff171e33b6f6f20674d94", null ],
    [ "deleteReminder", "interfacetech_1_1joestoolbox_1_1taskmanager_1_1service_1_1interfaces_1_1IReminderService.html#a62371b7783f9fef4c434865a822333f1", null ],
    [ "findAllRemindersOrderedByDeadline", "interfacetech_1_1joestoolbox_1_1taskmanager_1_1service_1_1interfaces_1_1IReminderService.html#ab17b030b17187ecccd118a646909d5ad", null ],
    [ "findReminderById", "interfacetech_1_1joestoolbox_1_1taskmanager_1_1service_1_1interfaces_1_1IReminderService.html#aa4265c8d429ae89b172377704a870042", null ],
    [ "patchReminder", "interfacetech_1_1joestoolbox_1_1taskmanager_1_1service_1_1interfaces_1_1IReminderService.html#a87e277ad5a4d2158908c90ee5e166ba2", null ],
    [ "updateReminder", "interfacetech_1_1joestoolbox_1_1taskmanager_1_1service_1_1interfaces_1_1IReminderService.html#aa850c6f1e6784e2fd3080c3561d0e25e", null ]
];