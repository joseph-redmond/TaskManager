var ProjectRepository_8java =
[
    [ "tech.joestoolbox.taskmanager.repository.ProjectRepository", "interfacetech_1_1joestoolbox_1_1taskmanager_1_1repository_1_1ProjectRepository.html", "interfacetech_1_1joestoolbox_1_1taskmanager_1_1repository_1_1ProjectRepository" ]
];