var interfacetech_1_1joestoolbox_1_1taskmanager_1_1repository_1_1TaskRepository =
[
    [ "findAllTasksOrderedByDeadlineAndUrgency", "interfacetech_1_1joestoolbox_1_1taskmanager_1_1repository_1_1TaskRepository.html#a6e3bde12e9166c7d62562f28af288513", null ]
];