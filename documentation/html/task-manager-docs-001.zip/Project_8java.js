var Project_8java =
[
    [ "tech.joestoolbox.taskmanager.entity.Project", "classtech_1_1joestoolbox_1_1taskmanager_1_1entity_1_1Project.html", "classtech_1_1joestoolbox_1_1taskmanager_1_1entity_1_1Project" ]
];