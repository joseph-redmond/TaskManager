var classtech_1_1joestoolbox_1_1taskmanager_1_1service_1_1implementation_1_1TaskService =
[
    [ "findTasksOrderedByDeadlineAndUrgency", "classtech_1_1joestoolbox_1_1taskmanager_1_1service_1_1implementation_1_1TaskService.html#aed5ef8eb9de3bd224c8b9ffbe9cf1186", null ],
    [ "CLASSNAME", "classtech_1_1joestoolbox_1_1taskmanager_1_1service_1_1implementation_1_1TaskService.html#a2af3ca3f1a830aaadd78240856d3cb8e", null ],
    [ "LOG", "classtech_1_1joestoolbox_1_1taskmanager_1_1service_1_1implementation_1_1TaskService.html#ab09f3110641fa80bf41d9da61a2a2f43", null ],
    [ "logAdapter", "classtech_1_1joestoolbox_1_1taskmanager_1_1service_1_1implementation_1_1TaskService.html#ad824ab2fa5decc583684a55889c029bf", null ],
    [ "taskRepository", "classtech_1_1joestoolbox_1_1taskmanager_1_1service_1_1implementation_1_1TaskService.html#a94b118179c333d4d7db896aadfcdb926", null ]
];