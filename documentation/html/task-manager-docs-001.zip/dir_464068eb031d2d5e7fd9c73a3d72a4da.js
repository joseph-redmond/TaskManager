var dir_464068eb031d2d5e7fd9c73a3d72a4da =
[
    [ "IProjectService.java", "IProjectService_8java.html", "IProjectService_8java" ],
    [ "IReminderService.java", "IReminderService_8java.html", "IReminderService_8java" ],
    [ "ITaskService.java", "ITaskService_8java.html", "ITaskService_8java" ]
];