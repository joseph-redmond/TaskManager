var TaskService_8java =
[
    [ "tech.joestoolbox.taskmanager.service.implementation.TaskService", "classtech_1_1joestoolbox_1_1taskmanager_1_1service_1_1implementation_1_1TaskService.html", "classtech_1_1joestoolbox_1_1taskmanager_1_1service_1_1implementation_1_1TaskService" ]
];