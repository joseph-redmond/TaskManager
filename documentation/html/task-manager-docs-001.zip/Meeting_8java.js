var Meeting_8java =
[
    [ "tech.joestoolbox.taskmanager.entity.Meeting", "classtech_1_1joestoolbox_1_1taskmanager_1_1entity_1_1Meeting.html", "classtech_1_1joestoolbox_1_1taskmanager_1_1entity_1_1Meeting" ]
];