var ReminderRepository_8java =
[
    [ "tech.joestoolbox.taskmanager.repository.ReminderRepository", "interfacetech_1_1joestoolbox_1_1taskmanager_1_1repository_1_1ReminderRepository.html", "interfacetech_1_1joestoolbox_1_1taskmanager_1_1repository_1_1ReminderRepository" ]
];