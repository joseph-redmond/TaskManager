var enumtech_1_1joestoolbox_1_1taskmanager_1_1enums_1_1ReminderType =
[
    [ "BILL", "enumtech_1_1joestoolbox_1_1taskmanager_1_1enums_1_1ReminderType.html#a8ec0070b77ce81968e10c8203d04ea31", null ],
    [ "GENERAL", "enumtech_1_1joestoolbox_1_1taskmanager_1_1enums_1_1ReminderType.html#a3ddc31c6236269c1c83249790791787d", null ],
    [ "MEDICAL", "enumtech_1_1joestoolbox_1_1taskmanager_1_1enums_1_1ReminderType.html#a4042fef05ab6dccd40bfb31ff39021f5", null ]
];