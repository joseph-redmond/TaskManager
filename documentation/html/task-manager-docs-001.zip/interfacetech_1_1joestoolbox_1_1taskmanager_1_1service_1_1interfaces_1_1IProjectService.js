var interfacetech_1_1joestoolbox_1_1taskmanager_1_1service_1_1interfaces_1_1IProjectService =
[
    [ "createProject", "interfacetech_1_1joestoolbox_1_1taskmanager_1_1service_1_1interfaces_1_1IProjectService.html#ac3d510757146292d4b82c3c14badff02", null ],
    [ "deleteProject", "interfacetech_1_1joestoolbox_1_1taskmanager_1_1service_1_1interfaces_1_1IProjectService.html#a600539b2d6bbd808a63d3e9b597b9de2", null ],
    [ "findProjectById", "interfacetech_1_1joestoolbox_1_1taskmanager_1_1service_1_1interfaces_1_1IProjectService.html#ac78206bbd957f1a12fa54d5cca67ed7a", null ],
    [ "patchProject", "interfacetech_1_1joestoolbox_1_1taskmanager_1_1service_1_1interfaces_1_1IProjectService.html#a12668386619131985540212f6d62e3c6", null ],
    [ "searchProjectsByTitle", "interfacetech_1_1joestoolbox_1_1taskmanager_1_1service_1_1interfaces_1_1IProjectService.html#a939297360ecc8f1066203b4cf5b4138d", null ],
    [ "updateProject", "interfacetech_1_1joestoolbox_1_1taskmanager_1_1service_1_1interfaces_1_1IProjectService.html#ab68c052ba3a8f2f17e8b7c66da57773e", null ]
];