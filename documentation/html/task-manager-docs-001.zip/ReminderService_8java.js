var ReminderService_8java =
[
    [ "tech.joestoolbox.taskmanager.service.implementation.ReminderService", "classtech_1_1joestoolbox_1_1taskmanager_1_1service_1_1implementation_1_1ReminderService.html", "classtech_1_1joestoolbox_1_1taskmanager_1_1service_1_1implementation_1_1ReminderService" ]
];