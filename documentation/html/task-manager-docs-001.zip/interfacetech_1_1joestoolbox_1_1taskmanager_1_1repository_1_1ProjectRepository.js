var interfacetech_1_1joestoolbox_1_1taskmanager_1_1repository_1_1ProjectRepository =
[
    [ "searchProjectsByTitle", "interfacetech_1_1joestoolbox_1_1taskmanager_1_1repository_1_1ProjectRepository.html#ab2e2e2af4c2bbfda7981618218ad0f79", null ]
];