var TaskAdapter_8java =
[
    [ "tech.joestoolbox.taskmanager.adapter.TaskAdapter", "classtech_1_1joestoolbox_1_1taskmanager_1_1adapter_1_1TaskAdapter.html", "classtech_1_1joestoolbox_1_1taskmanager_1_1adapter_1_1TaskAdapter" ]
];