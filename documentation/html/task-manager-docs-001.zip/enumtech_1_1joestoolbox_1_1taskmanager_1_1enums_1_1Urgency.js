var enumtech_1_1joestoolbox_1_1taskmanager_1_1enums_1_1Urgency =
[
    [ "HIGH", "enumtech_1_1joestoolbox_1_1taskmanager_1_1enums_1_1Urgency.html#a590589161772d24c3775fc339f547e96", null ],
    [ "LOW", "enumtech_1_1joestoolbox_1_1taskmanager_1_1enums_1_1Urgency.html#ab09349e811794252e90739ae75457b44", null ],
    [ "MEDIUM", "enumtech_1_1joestoolbox_1_1taskmanager_1_1enums_1_1Urgency.html#a0b08645387f083d95e4dd2dd1e315fa1", null ],
    [ "NO_PRIORITY", "enumtech_1_1joestoolbox_1_1taskmanager_1_1enums_1_1Urgency.html#a235c0cb8bb1c77ace1c9e27ce1685d99", null ],
    [ "URGENT", "enumtech_1_1joestoolbox_1_1taskmanager_1_1enums_1_1Urgency.html#a3f3b0e2719a57de8d76a7230a9a2ea38", null ]
];