var hierarchy =
[
    [ "tech.joestoolbox.taskmanager.service.interfaces.IProjectService", "interfacetech_1_1joestoolbox_1_1taskmanager_1_1service_1_1interfaces_1_1IProjectService.html", [
      [ "tech.joestoolbox.taskmanager.service.implementation.ProjectService", "classtech_1_1joestoolbox_1_1taskmanager_1_1service_1_1implementation_1_1ProjectService.html", null ]
    ] ],
    [ "tech.joestoolbox.taskmanager.service.interfaces.IReminderService", "interfacetech_1_1joestoolbox_1_1taskmanager_1_1service_1_1interfaces_1_1IReminderService.html", [
      [ "tech.joestoolbox.taskmanager.service.implementation.ReminderService", "classtech_1_1joestoolbox_1_1taskmanager_1_1service_1_1implementation_1_1ReminderService.html", null ]
    ] ],
    [ "tech.joestoolbox.taskmanager.service.interfaces.ITaskService", "interfacetech_1_1joestoolbox_1_1taskmanager_1_1service_1_1interfaces_1_1ITaskService.html", [
      [ "tech.joestoolbox.taskmanager.service.implementation.TaskService", "classtech_1_1joestoolbox_1_1taskmanager_1_1service_1_1implementation_1_1TaskService.html", null ]
    ] ],
    [ "tech.joestoolbox.taskmanager.entity.Project", "classtech_1_1joestoolbox_1_1taskmanager_1_1entity_1_1Project.html", null ],
    [ "tech.joestoolbox.taskmanager.constant.ProjectErrorMessage", "classtech_1_1joestoolbox_1_1taskmanager_1_1constant_1_1ProjectErrorMessage.html", null ],
    [ "tech.joestoolbox.taskmanager.constant.ReminderErrorMessage", "classtech_1_1joestoolbox_1_1taskmanager_1_1constant_1_1ReminderErrorMessage.html", null ],
    [ "tech.joestoolbox.taskmanager.enums.ReminderType", "enumtech_1_1joestoolbox_1_1taskmanager_1_1enums_1_1ReminderType.html", null ],
    [ "tech.joestoolbox.taskmanager.adapter.TaskAdapter", "classtech_1_1joestoolbox_1_1taskmanager_1_1adapter_1_1TaskAdapter.html", null ],
    [ "tech.joestoolbox.taskmanager.entity.TrackableObject", "classtech_1_1joestoolbox_1_1taskmanager_1_1entity_1_1TrackableObject.html", [
      [ "tech.joestoolbox.taskmanager.entity.Meeting", "classtech_1_1joestoolbox_1_1taskmanager_1_1entity_1_1Meeting.html", null ],
      [ "tech.joestoolbox.taskmanager.entity.Reminder", "classtech_1_1joestoolbox_1_1taskmanager_1_1entity_1_1Reminder.html", null ],
      [ "tech.joestoolbox.taskmanager.entity.Task", "classtech_1_1joestoolbox_1_1taskmanager_1_1entity_1_1Task.html", null ]
    ] ],
    [ "tech.joestoolbox.taskmanager.enums.Urgency", "enumtech_1_1joestoolbox_1_1taskmanager_1_1enums_1_1Urgency.html", null ],
    [ "JpaRepository", null, [
      [ "tech.joestoolbox.taskmanager.repository.ProjectRepository", "interfacetech_1_1joestoolbox_1_1taskmanager_1_1repository_1_1ProjectRepository.html", null ],
      [ "tech.joestoolbox.taskmanager.repository.ReminderRepository", "interfacetech_1_1joestoolbox_1_1taskmanager_1_1repository_1_1ReminderRepository.html", null ],
      [ "tech.joestoolbox.taskmanager.repository.TaskRepository", "interfacetech_1_1joestoolbox_1_1taskmanager_1_1repository_1_1TaskRepository.html", null ]
    ] ]
];