var ITaskService_8java =
[
    [ "tech.joestoolbox.taskmanager.service.interfaces.ITaskService", "interfacetech_1_1joestoolbox_1_1taskmanager_1_1service_1_1interfaces_1_1ITaskService.html", "interfacetech_1_1joestoolbox_1_1taskmanager_1_1service_1_1interfaces_1_1ITaskService" ]
];