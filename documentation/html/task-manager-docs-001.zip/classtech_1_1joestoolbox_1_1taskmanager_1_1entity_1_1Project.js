var classtech_1_1joestoolbox_1_1taskmanager_1_1entity_1_1Project =
[
    [ "description", "classtech_1_1joestoolbox_1_1taskmanager_1_1entity_1_1Project.html#aaa8148323135b3c9b091558602069ef3", null ],
    [ "id", "classtech_1_1joestoolbox_1_1taskmanager_1_1entity_1_1Project.html#abb0747c951e1ac86c66a162267aa25aa", null ],
    [ "title", "classtech_1_1joestoolbox_1_1taskmanager_1_1entity_1_1Project.html#af6903f2339b8278ba984f6fa2855e75a", null ]
];