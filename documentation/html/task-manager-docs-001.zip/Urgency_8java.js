var Urgency_8java =
[
    [ "tech.joestoolbox.taskmanager.enums.Urgency", "enumtech_1_1joestoolbox_1_1taskmanager_1_1enums_1_1Urgency.html", "enumtech_1_1joestoolbox_1_1taskmanager_1_1enums_1_1Urgency" ]
];