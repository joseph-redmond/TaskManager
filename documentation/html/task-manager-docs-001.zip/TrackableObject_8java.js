var TrackableObject_8java =
[
    [ "tech.joestoolbox.taskmanager.entity.TrackableObject", "classtech_1_1joestoolbox_1_1taskmanager_1_1entity_1_1TrackableObject.html", null ]
];