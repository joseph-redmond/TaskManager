var classtech_1_1joestoolbox_1_1taskmanager_1_1adapter_1_1TaskAdapter =
[
    [ "findTasksOrderedByDeadlineAndUrgency", "classtech_1_1joestoolbox_1_1taskmanager_1_1adapter_1_1TaskAdapter.html#ab059a6d8fc979692138ac9c8090576bb", null ],
    [ "CLASSNAME", "classtech_1_1joestoolbox_1_1taskmanager_1_1adapter_1_1TaskAdapter.html#ad2ea87e2c310148cb2ec60908df66ffc", null ],
    [ "LOG", "classtech_1_1joestoolbox_1_1taskmanager_1_1adapter_1_1TaskAdapter.html#ab4ad142b53b4208efc08849f60aa84b1", null ],
    [ "logAdapter", "classtech_1_1joestoolbox_1_1taskmanager_1_1adapter_1_1TaskAdapter.html#a873c236122cc9a93c56336807681188b", null ],
    [ "taskService", "classtech_1_1joestoolbox_1_1taskmanager_1_1adapter_1_1TaskAdapter.html#ae8ed45e956fe487828cdfc7ff14bf04b", null ]
];