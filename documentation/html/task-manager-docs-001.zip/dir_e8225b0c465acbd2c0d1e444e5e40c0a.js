var dir_e8225b0c465acbd2c0d1e444e5e40c0a =
[
    [ "ProjectRepository.java", "ProjectRepository_8java.html", "ProjectRepository_8java" ],
    [ "ReminderRepository.java", "ReminderRepository_8java.html", "ReminderRepository_8java" ],
    [ "TaskRepository.java", "TaskRepository_8java.html", "TaskRepository_8java" ]
];