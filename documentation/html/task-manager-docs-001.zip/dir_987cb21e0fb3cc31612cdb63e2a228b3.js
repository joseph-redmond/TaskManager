var dir_987cb21e0fb3cc31612cdb63e2a228b3 =
[
    [ "ProjectErrorMessage.java", "ProjectErrorMessage_8java.html", "ProjectErrorMessage_8java" ],
    [ "ReminderErrorMessage.java", "ReminderErrorMessage_8java.html", "ReminderErrorMessage_8java" ]
];