var searchData=
[
  ['general_0',['GENERAL',['../enumtech_1_1joestoolbox_1_1taskmanager_1_1enums_1_1ReminderType.html#a3ddc31c6236269c1c83249790791787d',1,'tech::joestoolbox::taskmanager::enums::ReminderType']]]
];
