var searchData=
[
  ['bill_0',['BILL',['../enumtech_1_1joestoolbox_1_1taskmanager_1_1enums_1_1ReminderType.html#a8ec0070b77ce81968e10c8203d04ea31',1,'tech::joestoolbox::taskmanager::enums::ReminderType']]],
  ['body_1',['body',['../classtech_1_1joestoolbox_1_1taskmanager_1_1entity_1_1Reminder.html#a716f4cda890d4fd2ff03992f01073933',1,'tech.joestoolbox.taskmanager.entity.Reminder.body'],['../classtech_1_1joestoolbox_1_1taskmanager_1_1entity_1_1Task.html#aebfa8190badbe0ffb4824cc2fbb59a79',1,'tech.joestoolbox.taskmanager.entity.Task.body']]]
];
