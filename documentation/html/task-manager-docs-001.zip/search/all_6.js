var searchData=
[
  ['id_0',['id',['../classtech_1_1joestoolbox_1_1taskmanager_1_1entity_1_1Meeting.html#a43ca8f0e6d5d4508bcbbcaea99b15913',1,'tech.joestoolbox.taskmanager.entity.Meeting.id'],['../classtech_1_1joestoolbox_1_1taskmanager_1_1entity_1_1Project.html#abb0747c951e1ac86c66a162267aa25aa',1,'tech.joestoolbox.taskmanager.entity.Project.id'],['../classtech_1_1joestoolbox_1_1taskmanager_1_1entity_1_1Reminder.html#a93b7fd79c39b03bf166359e2fcbb8f65',1,'tech.joestoolbox.taskmanager.entity.Reminder.id'],['../classtech_1_1joestoolbox_1_1taskmanager_1_1entity_1_1Task.html#a2a7cf071f46752422ac7733d7f405d08',1,'tech.joestoolbox.taskmanager.entity.Task.id']]],
  ['iprojectservice_1',['IProjectService',['../interfacetech_1_1joestoolbox_1_1taskmanager_1_1service_1_1interfaces_1_1IProjectService.html',1,'tech::joestoolbox::taskmanager::service::interfaces']]],
  ['iprojectservice_2ejava_2',['IProjectService.java',['../IProjectService_8java.html',1,'']]],
  ['ireminderservice_3',['IReminderService',['../interfacetech_1_1joestoolbox_1_1taskmanager_1_1service_1_1interfaces_1_1IReminderService.html',1,'tech::joestoolbox::taskmanager::service::interfaces']]],
  ['ireminderservice_2ejava_4',['IReminderService.java',['../IReminderService_8java.html',1,'']]],
  ['itaskservice_5',['ITaskService',['../interfacetech_1_1joestoolbox_1_1taskmanager_1_1service_1_1interfaces_1_1ITaskService.html',1,'tech::joestoolbox::taskmanager::service::interfaces']]],
  ['itaskservice_2ejava_6',['ITaskService.java',['../ITaskService_8java.html',1,'']]]
];
