var searchData=
[
  ['searchprojectsbytitle_0',['searchProjectsByTitle',['../interfacetech_1_1joestoolbox_1_1taskmanager_1_1repository_1_1ProjectRepository.html#ab2e2e2af4c2bbfda7981618218ad0f79',1,'tech.joestoolbox.taskmanager.repository.ProjectRepository.searchProjectsByTitle()'],['../classtech_1_1joestoolbox_1_1taskmanager_1_1service_1_1implementation_1_1ProjectService.html#ac52c0b88f32dd71e50139bf7017d4c57',1,'tech.joestoolbox.taskmanager.service.implementation.ProjectService.searchProjectsByTitle()'],['../interfacetech_1_1joestoolbox_1_1taskmanager_1_1service_1_1interfaces_1_1IProjectService.html#a939297360ecc8f1066203b4cf5b4138d',1,'tech.joestoolbox.taskmanager.service.interfaces.IProjectService.searchProjectsByTitle()']]]
];
