var searchData=
[
  ['deleteproject_0',['deleteProject',['../classtech_1_1joestoolbox_1_1taskmanager_1_1service_1_1implementation_1_1ProjectService.html#a6163f63e286c7fe0d844eaa60fd25ab8',1,'tech.joestoolbox.taskmanager.service.implementation.ProjectService.deleteProject()'],['../interfacetech_1_1joestoolbox_1_1taskmanager_1_1service_1_1interfaces_1_1IProjectService.html#a600539b2d6bbd808a63d3e9b597b9de2',1,'tech.joestoolbox.taskmanager.service.interfaces.IProjectService.deleteProject()']]],
  ['deletereminder_1',['deleteReminder',['../classtech_1_1joestoolbox_1_1taskmanager_1_1service_1_1implementation_1_1ReminderService.html#a6affbde748230af0df5263bf364e9b9c',1,'tech.joestoolbox.taskmanager.service.implementation.ReminderService.deleteReminder()'],['../interfacetech_1_1joestoolbox_1_1taskmanager_1_1service_1_1interfaces_1_1IReminderService.html#a62371b7783f9fef4c434865a822333f1',1,'tech.joestoolbox.taskmanager.service.interfaces.IReminderService.deleteReminder()']]]
];
