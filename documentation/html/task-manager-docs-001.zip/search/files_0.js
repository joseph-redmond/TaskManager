var searchData=
[
  ['iprojectservice_2ejava_0',['IProjectService.java',['../IProjectService_8java.html',1,'']]],
  ['ireminderservice_2ejava_1',['IReminderService.java',['../IReminderService_8java.html',1,'']]],
  ['itaskservice_2ejava_2',['ITaskService.java',['../ITaskService_8java.html',1,'']]]
];
