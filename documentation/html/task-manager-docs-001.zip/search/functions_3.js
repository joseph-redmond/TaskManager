var searchData=
[
  ['patchproject_0',['patchProject',['../classtech_1_1joestoolbox_1_1taskmanager_1_1service_1_1implementation_1_1ProjectService.html#a7da3b23e96610738f32438ec652fd3c6',1,'tech.joestoolbox.taskmanager.service.implementation.ProjectService.patchProject()'],['../interfacetech_1_1joestoolbox_1_1taskmanager_1_1service_1_1interfaces_1_1IProjectService.html#a12668386619131985540212f6d62e3c6',1,'tech.joestoolbox.taskmanager.service.interfaces.IProjectService.patchProject()']]],
  ['patchreminder_1',['patchReminder',['../classtech_1_1joestoolbox_1_1taskmanager_1_1service_1_1implementation_1_1ReminderService.html#ad6ccd047eb86f4f0ff3ccce6b176c761',1,'tech.joestoolbox.taskmanager.service.implementation.ReminderService.patchReminder()'],['../interfacetech_1_1joestoolbox_1_1taskmanager_1_1service_1_1interfaces_1_1IReminderService.html#a87e277ad5a4d2158908c90ee5e166ba2',1,'tech.joestoolbox.taskmanager.service.interfaces.IReminderService.patchReminder()']]]
];
