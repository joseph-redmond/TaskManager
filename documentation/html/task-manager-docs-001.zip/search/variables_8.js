var searchData=
[
  ['medical_0',['MEDICAL',['../enumtech_1_1joestoolbox_1_1taskmanager_1_1enums_1_1ReminderType.html#a4042fef05ab6dccd40bfb31ff39021f5',1,'tech::joestoolbox::taskmanager::enums::ReminderType']]],
  ['medium_1',['MEDIUM',['../enumtech_1_1joestoolbox_1_1taskmanager_1_1enums_1_1Urgency.html#a0b08645387f083d95e4dd2dd1e315fa1',1,'tech::joestoolbox::taskmanager::enums::Urgency']]]
];
