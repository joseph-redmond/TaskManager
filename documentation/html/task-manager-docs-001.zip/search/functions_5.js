var searchData=
[
  ['updateproject_0',['updateProject',['../classtech_1_1joestoolbox_1_1taskmanager_1_1service_1_1implementation_1_1ProjectService.html#a3ab1f3cd5f9018750d7b765d23dcf684',1,'tech.joestoolbox.taskmanager.service.implementation.ProjectService.updateProject()'],['../interfacetech_1_1joestoolbox_1_1taskmanager_1_1service_1_1interfaces_1_1IProjectService.html#ab68c052ba3a8f2f17e8b7c66da57773e',1,'tech.joestoolbox.taskmanager.service.interfaces.IProjectService.updateProject()']]],
  ['updatereminder_1',['updateReminder',['../classtech_1_1joestoolbox_1_1taskmanager_1_1service_1_1implementation_1_1ReminderService.html#a3194bb636f6f2387c6e0848123af5674',1,'tech.joestoolbox.taskmanager.service.implementation.ReminderService.updateReminder()'],['../interfacetech_1_1joestoolbox_1_1taskmanager_1_1service_1_1interfaces_1_1IReminderService.html#aa850c6f1e6784e2fd3080c3561d0e25e',1,'tech.joestoolbox.taskmanager.service.interfaces.IReminderService.updateReminder()']]]
];
