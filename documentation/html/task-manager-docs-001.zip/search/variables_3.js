var searchData=
[
  ['failed_5fto_5ffind_5fby_5fid_0',['FAILED_TO_FIND_BY_ID',['../classtech_1_1joestoolbox_1_1taskmanager_1_1constant_1_1ProjectErrorMessage.html#a59715e36419fb819976129c2abd9b51f',1,'tech.joestoolbox.taskmanager.constant.ProjectErrorMessage.FAILED_TO_FIND_BY_ID'],['../classtech_1_1joestoolbox_1_1taskmanager_1_1constant_1_1ReminderErrorMessage.html#aae7b5e874e0bc3ac586783f4799cc035',1,'tech.joestoolbox.taskmanager.constant.ReminderErrorMessage.FAILED_TO_FIND_BY_ID']]]
];
