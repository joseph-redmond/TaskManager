var searchData=
[
  ['deadline_0',['deadline',['../classtech_1_1joestoolbox_1_1taskmanager_1_1entity_1_1Meeting.html#aaf2af66db6247ff2610687c331fc1f37',1,'tech.joestoolbox.taskmanager.entity.Meeting.deadline'],['../classtech_1_1joestoolbox_1_1taskmanager_1_1entity_1_1Reminder.html#a455053b2d98aff72ef3defda0976296f',1,'tech.joestoolbox.taskmanager.entity.Reminder.deadline'],['../classtech_1_1joestoolbox_1_1taskmanager_1_1entity_1_1Task.html#a3f54d6791d0951ef7816d94451e0061f',1,'tech.joestoolbox.taskmanager.entity.Task.deadline']]],
  ['description_1',['description',['../classtech_1_1joestoolbox_1_1taskmanager_1_1entity_1_1Meeting.html#ab7149f62fb2ffd6158a0485f8ec36aea',1,'tech.joestoolbox.taskmanager.entity.Meeting.description'],['../classtech_1_1joestoolbox_1_1taskmanager_1_1entity_1_1Project.html#aaa8148323135b3c9b091558602069ef3',1,'tech.joestoolbox.taskmanager.entity.Project.description']]]
];
