var searchData=
[
  ['project_0',['project',['../classtech_1_1joestoolbox_1_1taskmanager_1_1entity_1_1Task.html#abde62eb421387c391c762ce44d5520ca',1,'tech::joestoolbox::taskmanager::entity::Task']]],
  ['projectrepository_1',['projectRepository',['../classtech_1_1joestoolbox_1_1taskmanager_1_1service_1_1implementation_1_1ProjectService.html#aebc65088c0505783f60b7bb554f1f41a',1,'tech::joestoolbox::taskmanager::service::implementation::ProjectService']]]
];
