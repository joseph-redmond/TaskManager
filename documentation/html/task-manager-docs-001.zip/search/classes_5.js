var searchData=
[
  ['urgency_0',['Urgency',['../enumtech_1_1joestoolbox_1_1taskmanager_1_1enums_1_1Urgency.html',1,'tech::joestoolbox::taskmanager::enums']]]
];
