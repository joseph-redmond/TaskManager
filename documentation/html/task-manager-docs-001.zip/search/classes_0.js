var searchData=
[
  ['iprojectservice_0',['IProjectService',['../interfacetech_1_1joestoolbox_1_1taskmanager_1_1service_1_1interfaces_1_1IProjectService.html',1,'tech::joestoolbox::taskmanager::service::interfaces']]],
  ['ireminderservice_1',['IReminderService',['../interfacetech_1_1joestoolbox_1_1taskmanager_1_1service_1_1interfaces_1_1IReminderService.html',1,'tech::joestoolbox::taskmanager::service::interfaces']]],
  ['itaskservice_2',['ITaskService',['../interfacetech_1_1joestoolbox_1_1taskmanager_1_1service_1_1interfaces_1_1ITaskService.html',1,'tech::joestoolbox::taskmanager::service::interfaces']]]
];
